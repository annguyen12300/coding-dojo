//Predic 1: console.log will state the born year plus 1980 for the result
//Predict 2: console.log will state the year that born without adding the 1980
//Predict 3: console.log will state 30